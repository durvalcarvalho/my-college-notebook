﻿/*
* Nome: Julio Cesar Litwin Lima
* Matricula: 16/0129443
* Data: 17/10/2019
*
* => 01 banco de dado
* => 08 tabelas
*/

CREATE DATABASE bdAmbiente;
USE bdAmbiente;

CREATE TABLE PESSOA (
    nome VARCHAR(100),
    idPessoa INT AUTO_INCREMENT PRIMARY KEY,
    dtNascimento DATE NOT NULL,
    sexo BOOLEAN NOT NULL,
    apelido VARCHAR(32) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE CARACTERISTICA (
    idCaracterista INT AUTO_INCREMENT PRIMARY KEY,
    caracteristica VARCHAR(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE INTERESSE (
    idInteresse INT AUTO_INCREMENT PRIMARY KEY,
    interesse VARCHAR(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE RELACIONAMENTO (
    idRelacionamento INT AUTO_INCREMENT PRIMARY KEY,
    relacionaPessoa INT NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE email (
    idPessoa INT NOT NULL PRIMARY KEY,
    email VARCHAR(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE possui (
    fk_PESSOA_idPessoa INT NOT NULL,
    fk_CARACTERISTICA_idCaracterista INT NOT NULL
) ENGINE=InnoDB;

CREATE TABLE tem (
    fk_INTERESSE_idInteresse INT NOT NULL,
    fk_PESSOA_idPessoa INT NOT NULL
) ENGINE=InnoDB;

CREATE TABLE relaciona (
    fk_RELACIONAMENTO_idRelacionamento INT NOT NULL,
    fk_PESSOA_idPessoa INT NOT NULL
) ENGINE=InnoDB;