﻿/*
* Nome: Julio Cesar Litwin Lima
* Matricula: 16/0129443
* Data: 17/10/2019
*
* => 01 banco de dado
* => 08 tabelas
*/

USE bdAmbiente;

DROP TABLE PESSOA;
DROP TABLE CARACTERISTICA;
DROP TABLE INTERESSE;
DROP TABLE RELACIONAMENTO;
DROP TABLE email;
DROP TABLE possui;
DROP TABLE tem;
DROP TABLE relaciona;