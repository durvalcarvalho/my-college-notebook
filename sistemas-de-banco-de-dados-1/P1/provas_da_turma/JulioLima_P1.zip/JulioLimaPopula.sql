﻿/*
* Nome: Julio Cesar Litwin Lima
* Matricula: 16/0129443
* Data: 17/10/2019
*
* => 01 banco de dado
* => 08 tabelas
*/

USE bdAmbiente;

/* PESSOA */
INSERT INTO PESSOA(nome, dtNascimento, sexo, apelido)
  VALUES ('Julio Cesar Litwin Lima', DATE('1996-08-02'), 0, 'Litwin');

INSERT INTO PESSOA(nome, dtNascimento, sexo, apelido)
  VALUES ('Anna Luiza Souza', DATE('1998-01-12'), 1, 'Anninha');

INSERT INTO PESSOA(nome, dtNascimento, sexo, apelido)
  VALUES ('Lucas da Silva', DATE('1996-08-04'), 0, 'Noob');

/* email */
INSERT INTO email(idPessoa, email)
  VALUES(1, 'j.litwin@live.com');

INSERT INTO email(idPessoa, email)
  VALUES(1, 'julioclitwin@gmail.com');

INSERT INTO email(idPessoa, email)
  VALUES(2, 'annaluizazinha@hotmail.com');

INSERT INTO email(idPessoa, email)
  VALUES(3, 'lucas_silvas_s0@gmail.com');

/* INTERESSE */
INSERT INTO INTERESSE(interesse)
  VALUES('Jogos');

INSERT INTO INTERESSE(interesse)
  VALUES('Musicas');

INSERT INTO INTERESSE(interesse)
  VALUES('Desenvolvimento de Software');

INSERT INTO INTERESSE(interesse)
  VALUES('Estudar');

INSERT INTO INTERESSE(interesse)
  VALUES('Cozinhar');

INSERT INTO INTERESSE(interesse)
  VALUES('Animais');

/* tem */
INSERT INTO tem(fk_INTERESSE_idInteresse, fk_PESSOA_idPessoa)
  VALUES(1, 1);

INSERT INTO tem(fk_INTERESSE_idInteresse, fk_PESSOA_idPessoa)
  VALUES(2, 1);

INSERT INTO tem(fk_INTERESSE_idInteresse, fk_PESSOA_idPessoa)
  VALUES(1, 2);

INSERT INTO tem(fk_INTERESSE_idInteresse, fk_PESSOA_idPessoa)
  VALUES(6, 2);

INSERT INTO tem(fk_INTERESSE_idInteresse, fk_PESSOA_idPessoa)
  VALUES(5, 3);

INSERT INTO tem(fk_INTERESSE_idInteresse, fk_PESSOA_idPessoa)
  VALUES(3, 3);

/* CARACTERISTICA */
INSERT INTO CARACTERISTICA(caracteristica)
  VALUES('Sincero');

INSERT INTO CARACTERISTICA(caracteristica)
  VALUES('Divertido');

INSERT INTO CARACTERISTICA(caracteristica)
  VALUES('Sedentario');

INSERT INTO CARACTERISTICA(caracteristica)
  VALUES('Cantor');

/* possui */
INSERT INTO possui(fk_PESSOA_idPessoa, fk_CARACTERISTICA_idCaracterista)
  VALUES(1, 1);

INSERT INTO possui(fk_PESSOA_idPessoa, fk_CARACTERISTICA_idCaracterista)
  VALUES(2, 2);

INSERT INTO possui(fk_PESSOA_idPessoa, fk_CARACTERISTICA_idCaracterista)
  VALUES(3, 1);

/* RELACIONAMENTO */
INSERT INTO RELACIONAMENTO(relacionaPessoa)
  VALUES(2);

INSERT INTO RELACIONAMENTO(relacionaPessoa)
  VALUES(3);

INSERT INTO RELACIONAMENTO(relacionaPessoa)
  VALUES(1);

INSERT INTO RELACIONAMENTO(relacionaPessoa)
  VALUES(3);

/* relaciona */
INSERT INTO relaciona(fk_RELACIONAMENTO_idRelacionamento, fk_PESSOA_idPessoa)
  VALUES(1, 1);

INSERT INTO relaciona(fk_RELACIONAMENTO_idRelacionamento, fk_PESSOA_idPessoa)
  VALUES(2, 1);

INSERT INTO relaciona(fk_RELACIONAMENTO_idRelacionamento, fk_PESSOA_idPessoa)
  VALUES(3, 2);

INSERT INTO relaciona(fk_RELACIONAMENTO_idRelacionamento, fk_PESSOA_idPessoa)
  VALUES(4, 2);