﻿CREATE DATABASE IF NOT EXISTS lucascarvalho  ;

USE lucascarvalho;

CREATE TABLE PESSOA (
    nome VARCHAR(30),
    idade INTEGER,
    sexo CHAR,
    dataNascimento DATE,
    email VARCHAR(30) NOT NULL PRIMARY KEY
)ENGINE = InnoDB;

CREATE TABLE CARACTERISTICA (
    descricao VARCHAR(30)
)ENGINE = InnoDB;

CREATE TABLE PERFIL (
    primeiroNome VARCHAR(15) NOT NULL,
    segundoNome VARCHAR(15) NOT NULL,
    apelido VARCHAR(15) NOT NULL PRIMARY KEY,
    email VARCHAR(30) NOT NULL
)ENGINE = InnoDB;

CREATE TABLE relaciona (
    apelido VARCHAR(15)
)ENGINE = InnoDB;

CREATE TABLE possui (
    apelido VARCHAR(15)
)ENGINE = InnoDB;

CREATE TABLE possui (
    apelido VARCHAR(15)
)ENGINE = InnoDB;