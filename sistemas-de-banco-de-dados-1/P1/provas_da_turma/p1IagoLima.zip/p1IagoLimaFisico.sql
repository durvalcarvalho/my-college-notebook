﻿-- --------     << Prova AV1 >>     ------------
--
--                    SCRIPT DE CRIACAO (DML)
-- 
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Iago Theóphilo de Lima
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: bdProva
--
-- PROJETO => 01 Base de Dados
--         => 07 Tabelas
--
-- -----------------------------------------------------------------
CREATE DATABASE  bdProva;
use bdProva;

CREATE TABLE PERIODO (
    idPeriodo int NOT NULL AUTO_INCREMENT,
    nomePeriodo varchar(50) NOT NULL,
  CONSTRAINT PERIODO_PK Primary Key(idPeriodo)
)ENGINE=Innodb AUTO_INCREMENT=1;

CREATE TABLE DISCIPLINA (
    nome varchar(100) NOT NULL,
    sigla varchar(50) NOT NULL,
    qntCreditos int NOT NULL,
    idPeriodo int NOT NULL,
CONSTRAINT DISCIPLINA_PK Primary Key(sigla),
CONSTRAINT FK_DISCIPLINA_2 FOREIGN KEY (idPeriodo)
    REFERENCES PERIODO (idPeriodo)
)ENGINE=Innodb;

CREATE TABLE PRE_REQUISITO (
    siglaPre int NOT NULL,
    nome varchar(100) NOT NULL,
  CONSTRAINT PRE_REQUISITO_PK Primary Key(siglaPre)
)ENGINE=Innodb;

CREATE TABLE PROFESSOR (
    ultimoNome varchar(50) NOT NULL,
    dtNascimento varchar(50) NOT NULL,
    primeiroNome varchar(50) NOT NULL,
    sexo varchar(20) NOT NULL,
    idade int NOT NULL,
    cpf varchar(11) NOT NULL,
CONSTRAINT PROFESSOR_PK Primary Key(cpf)
)ENGINE=Innodb;



CREATE TABLE email (
    cpf varchar(11) NOT NULL,
    email varchar(50) NOT NULL,
CONSTRAINT email_FK FOREIGN KEY (cpf)
    REFERENCES PROFESSOR (cpf),
CONSTRAINT email_PK Primary Key(email)
)ENGINE=Innodb;

CREATE TABLE tem (
    sigla varchar(50),
    siglaPre int,
CONSTRAINT FK_tem_1 FOREIGN KEY (sigla)
    REFERENCES DISCIPLINA (sigla),
CONSTRAINT FK_tem_2 FOREIGN KEY (siglaPre)
    REFERENCES PRE_REQUISITO (siglaPre)
)ENGINE=Innodb;

CREATE TABLE contem (
    sigla varchar(50) NOT NULL,
    cpf varchar(11) NOT NULL,
CONSTRAINT FK_contem_1 FOREIGN KEY (sigla)
    REFERENCES DISCIPLINA (sigla),
CONSTRAINT FK_contem_2 FOREIGN KEY (cpf)
    REFERENCES PROFESSOR (cpf)

)ENGINE=Innodb;