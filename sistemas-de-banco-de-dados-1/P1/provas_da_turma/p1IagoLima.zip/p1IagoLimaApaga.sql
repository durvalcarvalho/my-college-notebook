﻿-- --------     << Prova AV1 >>     ------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Iago Theóphilo de Lima
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: bdProva
--
-- PROJETO => 01 Base de Dados
--         => 07 Tabelas
--
-- -----------------------------------------------------------------
use bdProva;

DROP table tem;
DROP table contem;
DROP table PRE_REQUISITO;

DROP table DISCIPLINA;
DROP table PERIODO;

DROP table email;

DROP table PROFESSOR;



