USE lucassilva;

INSERT INTO email(idEmail, email) VALUES
	(NULL, 'joaoRibeiro@gnail.com');
INSERT INTO email(idEmail, email) VALUES
	(NULL, 'roberto10@gnail.com');

