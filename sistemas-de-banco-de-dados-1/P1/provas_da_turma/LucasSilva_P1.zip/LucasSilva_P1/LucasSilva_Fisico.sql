CREATE DATABASE IF NOT EXISTS lucasSilva;
USE lucasSilva;

CREATE TABLE email (
    idEmail INT NOT NULL AUTO_INCREMENT,
    email VARCHAR(50) NOT NULL,
    CONSTRAINT email_PK PRIMARY KEY(idEmail)
)ENGINE=INNODB AUTO_INCREMENT=1;

CREATE TABLE PESSOA (
    idPessoa INT NOT NULL AUTO_INCREMENT,
    primeiroNome VARCHAR(30) NOT NULL,
    ultimoNome VARCHAR(30) NOT NULL,
    apelido VARCHAR(30) NOT NULL,
    sexo CHAR(1) NOT NULL,
    dtNascimento DATE NOT NULL,
    idEmail INT NOT NULL,
    CONSTRAINT pessoa_PK PRIMARY KEY(idPessoa),
    CONSTRAINT pessoa_email_FK FOREIGN KEY (idEmail)
    	REFERENCES email (idEmail)
)ENGINE=INNODB AUTO_INCREMENT=1;

CREATE TABLE CARACTERISTICA_PESSOAL (
    idCaracteristica INT NOT NULL AUTO_INCREMENT,
    descricao VARCHAR(50) NOT NULL,
    CONSTRAINT caracteristicaPessoal_PK PRIMARY KEY(idCaracteristica)
)ENGINE=INNODB AUTO_INCREMENT=1;

CREATE TABLE INTERESSE (
    idInteresse INT NOT NULL AUTO_INCREMENT,
    descricao VARCHAR(50) NOT NULL,
    CONSTRAINT interesse_PK PRIMARY KEY(idInteresse)
)ENGINE=INNODB AUTO_INCREMENT=1;

CREATE TABLE relaciona (
    idPessoa INT NOT NULL,
    idOutraPessoa INT NOT NULL,
    CONSTRAINT relaciona_pessoa_FK FOREIGN KEY (idPessoa)
    	REFERENCES PESSOA (idPessoa),
    CONSTRAINT relaciona_pessoab_FK FOREIGN KEY (idOutraPessoa)
    	REFERENCES PESSOA (idPessoa)
);

CREATE TABLE possui (
    idInteresse INT NOT NULL,
    idPessoa INT NOT NULL,
    CONSTRAINT possui_interesse_FK FOREIGN KEY (idInteresse)
    	REFERENCES INTERESSE (idInteresse),
    CONSTRAINT possui_pessoa_FK FOREIGN KEY (idPessoa)
    	REFERENCES PESSOA (idPessoa)
);

CREATE TABLE tem (
    idCaracteristica INT NOT NULL,
    idPessoa INT NOT NULL,
    CONSTRAINT tem_caracteristicaPessoal_FK FOREIGN KEY (idCaracteristica)
    	REFERENCES CARACTERISTICA_PESSOAL (idCaracteristica),
    CONSTRAINT tem_pessoa_FK FOREIGN KEY (idPessoa)
    	REFERENCES PESSOA (idPessoa)
);
