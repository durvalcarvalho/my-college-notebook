﻿-- --------     << COLOCAR O NOME DE SEU PROJETO >>     ------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 17/10/2018
-- Autor(es) ..............: Geraldo Victor Alves Barbosa
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: geraldobarbosa
--
--   => Criacao de nova tabela
--
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
--
-- -----------------------------------------------------------------
CREATE DATABASE IF NOT EXISTS geraldobarbosa

use geraldobarbosa

CREATE TABLE INTERESSE (
    descInteresse varchar(500) not null
)Engine = InnoBD;

CREATE TABLE CARACTERISTICA (
    descCaracteristica varchar(500) not null
)Engine = InnoBD;

CREATE TABLE INTERESSADA (
    dtNascimento date not null,
    nome vachar(50) not null,
    sexo enum('M','F') not null,
    apelido varchar(20) not null,
    idPessoa bigint not null PRIMARY KEY AUTO_INCREMENT
)Engine = InnoBD;

CREATE TABLE INDICADA (
    dtNascimento date not null,
    nome varchar(50) not null,
    sexo enum('F','M') not null,
    apelido varchar(20) not null,
    idPessoa bigint not null PRIMARY KEY AUTO_INCREMENT
)Engine = InnoBD;

CREATE TABLE email (
    idPessoa bigint NOT NULL PRIMARY KEY,
    email varchar(100) not null
)Engine = InnoBD;

CREATE TABLE relaciona (
    idPessoa bigint not null,
    idPessoa bigint not null
)Engine = InnoBD;

CREATE TABLE tem (
    idPessoa bigint not null,
    idPessoa bigint not null
)Engine = InnoBD;

CREATE TABLE possui (
    idPessoa bigint not null,
    idPessoa bigint not null
)Engine = InnoBD;
