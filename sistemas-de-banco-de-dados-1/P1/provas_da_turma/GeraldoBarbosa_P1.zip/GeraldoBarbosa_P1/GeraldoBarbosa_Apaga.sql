﻿-- --------     << COLOCAR O NOME DE SEU PROJETO >>     ------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 17/10/2018
-- Autor(es) ..............: Geraldo Victor Alves Barbosa
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: geraldobarbosa
--
--   => Apaga tabelas
--
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
--
-- -----------------------------------------------------------------
use geraldobarbosa

drop TABLE INTERESSE;
drop TABLE CARACTERISTICA;
drop TABLE INTERESSADA;
drop TABLE INDICADA;
drop TABLE email;
drop TABLE relaciona;
drop TABLE tem;
drop TABLE possui;
