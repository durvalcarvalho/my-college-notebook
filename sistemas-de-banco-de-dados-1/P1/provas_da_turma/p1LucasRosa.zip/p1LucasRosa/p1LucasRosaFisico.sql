﻿/* p1LucasRosaLogico: */
CREATE DATABASE lucasrosa IF NOT EXISTS;

USE lucasrosa;

CREATE TABLE DISCIPLINA (
    nomeCompleto VARCHAR NOT NULL PRIMARY KEY,
    sigla VARCHAR NOT NULL,
    qtdCreditos INT NOT NULL,
    periodo VARCHAR NOT NULL,
)ENGINE = InnoDB;

CREATE TABLE PRE_REQUISITO (
    nomeCompleto VARCHAR PRIMARY KEY NOT NULL
)ENGINE = InnoDB;

CREATE TABLE PROFESSOR (
    primeiroNome VARCHAR NOT NULL,
    ultimoNome VARCHAR NOT NULL,
    dtNascimento DATE NOT NULL,
    sexo VARCHAR NOT NULL,
    FK_email_email_PK VARCHAR NOT NULL,
    idProfessor INT PRIMARY KEY AUTO_INCREMENT=1
)ENGINE = InnoDB;

CREATE TABLE email (
    FK_idProfessor INT NOT NULL PRIMARY KEY,
    email VARCHAR NOT NULL
)ENGINE = InnoDB;

CREATE TABLE possui (
    fk_DISCIPLINA_nomeCompleto VARCHAR,
    fk_PRE_REQUISITO_nomeCompleto VARCHAR
)ENGINE = InnoDB;

CREATE TABLE leciona (
    fk_DISCIPLINA_nomeCompleto VARCHAR,
    fk_PROFESSOR_idProfessor INT
)ENGINE = InnoDB;

ALTER TABLE PROFESSOR ADD CONSTRAINT FK_PROFESSOR_2
    FOREIGN KEY (FK_email_email_PK)
    REFERENCES email (email_PK)
    ON DELETE NO ACTION;
 
ALTER TABLE possui ADD CONSTRAINT FK_possui_1
    FOREIGN KEY (fk_DISCIPLINA_nomeCompleto)
    REFERENCES DISCIPLINA (nomeCompleto)
    ON DELETE RESTRICT;
 
ALTER TABLE possui ADD CONSTRAINT FK_possui_2
    FOREIGN KEY (fk_PRE_REQUISITO_nomeCompleto)
    REFERENCES PRE_REQUISITO (nomeCompleto)
    ON DELETE SET NULL;
 
ALTER TABLE leciona ADD CONSTRAINT FK_leciona_1
    FOREIGN KEY (fk_DISCIPLINA_nomeCompleto)
    REFERENCES DISCIPLINA (nomeCompleto)
    ON DELETE RESTRICT;
 
ALTER TABLE leciona ADD CONSTRAINT FK_leciona_2
    FOREIGN KEY (fk_PROFESSOR_idProfessor)
    REFERENCES PROFESSOR (idProfessor)
    ON DELETE RESTRICT;