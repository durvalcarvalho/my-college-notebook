﻿USE lucasrosa

INSERT INTO DISCIPLINA VALUES ('Calculo 1', 'C1', 6, 'Vespertino');
INSERT INTO DISCIPLINA VALUES ('Calculo 2', 'C2', 6, 'Matutino');
INSERT INTO DISCIPLINA VALUES ('Calculo 3', 'C3', 6, 'Noturno');
INSERT INTO DISCIPLINA VALUES ('Desenho industrial', 'DI', 4, 'Vespertino');

INSERT INTO PRE_REQUISITO VALUES ('Calculo 1');
INSERT INTO PRE_REQUISITO VALUES ('Calculo 2');
INSERT INTO PRE_REQUISITO VALUES ('Desenho industrial');

INSERT INTO PROFESSOR VALUES ('Vinicius', 'Rispolli', 04-10-1976, 'Masculino', 1);
INSERT INTO PROFESSOR VALUES ('Flavia', 'Medeiros', 12-09-1980, 'Feminino', 2);
INSERT INTO PROFESSOR VALUES ('Maria', 'Carvalho', 01-01-1995, 'Feminino', 3);

INSERT INTO possui VALUES ('Calculo 2', 'Calculo 1');
INSERT INTO possui VALUES ('Calculo 3', 'Calculo 2');

INSERT INTO leciona VALUES ('Calculo 2', 1);
INSERT INTO leciona VALUES ('Calculo 1', 2);