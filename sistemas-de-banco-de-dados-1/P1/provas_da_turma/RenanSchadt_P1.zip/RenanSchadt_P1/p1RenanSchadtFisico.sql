﻿-- --------    RenanSchadtP1     ------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Renan Welz Schadt
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: renanschadt
--
--
-- PROJETO => 01 Base de Dados
--         => 07 Tabelas
--
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS renanschadt;
USE renanschadt;


CREATE TABLE PESSOA (
    dtNasc DATE NOT NULL,
    sexo VARCHAR(1) NOT NULL,
    apelido VARCHAR(20) NOT NULL,
    nome VARCHAR(40) NOT NULL,
    idPessoa INT NOT NULL AUTO_INCREMENT,

    CONSTRAINT PK_PESSOA PRIMARY KEY (idPessoa)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE CARACTERISTICA (
    idCaracteristica INT NOT NULL AUTO_INCREMENT,
    descCaracteristica VARCHAR(100) NOT NULL,

    CONSTRAINT PK_CARACTERISTICA PRIMARY KEY (idCaracteristica)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE INTERESSE (
    idInteresse INT NOT NULL AUTO_INCREMENT,
    descInteresse VARCHAR(100) NOT NULL,

    CONSTRAINT PK_INTERESSE PRIMARY KEY (idInteresse)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE email (
    idPessoa INT NOT NULL,
    email VARCHAR(60) NOT NULL,
    CONSTRAINT PK_email PRIMARY KEY (idPessoa, email),
    CONSTRAINT FK_email_PESSOA FOREIGN KEY (idPessoa) REFERENCES PESSOA (idPessoa)
) ENGINE = InnoDB;

CREATE TABLE relaciona (
    idPessoa1 INT NOT NULL,
    idPessoa2 INT NOT NULL,

    CONSTRAINT FK_relaciona_PESSOA1 FOREIGN KEY (idPessoa1) REFERENCES PESSOA (idPessoa),
    CONSTRAINT FK_relaciona_PESSOA2 FOREIGN KEY (idPessoa2) REFERENCES PESSOA (idPessoa)
) ENGINE = InnoDB;

CREATE TABLE possui (
    idPessoa INT NOT NULL,
    idCaracteristica INT NOT NULL,

    CONSTRAINT FK_possui_PESSOA FOREIGN KEY (idPessoa) REFERENCES PESSOA (idPessoa),
    CONSTRAINT FK_possui_CARACTERISTICA FOREIGN KEY (idCaracteristica) REFERENCES CARACTERISTICA (idCaracteristica)
) ENGINE = InnoDB;

CREATE TABLE tem (
    idPessoa INT NOT NULL,
    idInteresse INT NOT NULL,

    CONSTRAINT FK_tem_PESSOA FOREIGN KEY (idPessoa) REFERENCES PESSOA (idPessoa),
    CONSTRAINT FK_tem_INTERESSE FOREIGN KEY (idInteresse) REFERENCES INTERESSE (idInteresse)
) ENGINE = InnoDB;