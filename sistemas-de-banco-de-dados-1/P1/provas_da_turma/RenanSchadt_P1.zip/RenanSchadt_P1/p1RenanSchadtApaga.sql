﻿-- --------    RenanSchadtP1     ------------
--
--                    SCRIPT APAGA (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Renan Welz Schadt
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: renanschadt
--
--
-- PROJETO => 01 Base de Dados
--         => 07 Tabelas
--
-- -----------------------------------------------------------------

USE renanschadt;

DROP TABLE tem;
DROP TABLE possui;
DROP TABLE email;
DROP TABLE relaciona;
DROP TABLE CARACTERISTICA;
DROP TABLE INTERESSE;
DROP TABLE PESSOA;