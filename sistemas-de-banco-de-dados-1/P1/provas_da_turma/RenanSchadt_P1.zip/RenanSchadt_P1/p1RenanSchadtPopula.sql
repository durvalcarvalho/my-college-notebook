﻿-- --------    RenanSchadtP1     ------------
--
--                    SCRIPT DE POPULA (DML)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Renan Welz Schadt
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: renanschadt
--
--
-- PROJETO => 01 Base de Dados
--         => 07 Tabelas
--
-- -----------------------------------------------------------------


USE renanschadt;

INSERT INTO PESSOA (dtNasc, sexo, apelido, nome) VALUES ('1996-11-25', 'M', 'nanan', 'Renan Ribas');
INSERT INTO PESSOA (dtNasc, sexo, apelido, nome) VALUES ('2000-10-11', 'F', 'juju', 'Juliana Camargo');
INSERT INTO PESSOA (dtNasc, sexo, apelido, nome) VALUES ('1997-12-18', 'F', 'jaqz', 'Jaquelino Martins');

INSERT INTO CARACTERISTICA (descCaracteristica) VALUES ('Alto astral');
INSERT INTO CARACTERISTICA (descCaracteristica) VALUES ('Sorridente');

INSERT INTO INTERESSE (descInteresse) VALUES ('Futebol');
INSERT INTO INTERESSE (descInteresse) VALUES ('Viagem');

INSERT INTO email (idPessoa, email) VALUES (1, 'renanribas@gmail.com');
INSERT INTO email (idPessoa, email) VALUES (2, 'jujuC@gmail.com');
INSERT INTO email (idPessoa, email) VALUES (3, 'jaqZ@gmail.com');

INSERT INTO relaciona (idPessoa1, idPessoa2) VALUES (1, 2);
INSERT INTO relaciona (idPessoa1, idPessoa2) VALUES (1, 3);

INSERT INTO possui (idPessoa, idCaracteristica) VALUES (1, 1);
INSERT INTO possui (idPessoa, idCaracteristica) VALUES (2, 1);
INSERT INTO possui (idPessoa, idCaracteristica) VALUES (3, 2);

INSERT INTO tem (idPessoa, idInteresse) VALUES (1, 1);
INSERT INTO tem (idPessoa, idInteresse) VALUES (2, 1);
INSERT INTO tem (idPessoa, idInteresse) VALUES (3, 2);
