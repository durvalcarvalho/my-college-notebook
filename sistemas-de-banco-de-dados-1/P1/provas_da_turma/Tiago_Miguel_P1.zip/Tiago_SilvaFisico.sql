﻿-- --------     << COLOCAR O NOME DE SEU PROJETO >>     ------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 21/03/2018
-- Autor(es) ..............: Ana Maria Braga
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: bdFinanceiro
--
-- Data Ultima Alteracao ..: 28/03/2017
--   => Criacao de nova tabela
-- 
-- PROJETO => 01 Base de Dados
--         => 11 Tabelas
--         => 02 Sequencias
--         => 02 Visoes
--
-- -----------------------------------------------------------------
CREATE DATABASE
CREATE TABLE PESSOA (
    idade int,
    idPessoa int PRIMARY KEY,
    apelido varchar(20),
    nomePerfil varchar(20),
    nome varchar(50),
    FK_email_email_PK int,
    sexo char,
    dataNascimento date
);

CREATE TABLE CARACTERISTICA (
    idCaracteristica int PRIMARY KEY,
    caracteristica varchar(20)
);

CREATE TABLE RELACIONAMENTO (
    idRelacionamento int PRIMARY KEY
);

CREATE TABLE email (
    email_PK int NOT NULL PRIMARY KEY,
    email varchar(20)
);

CREATE TABLE possui (
    fk_CARACTERISTICA_idCaracteristica int,
    fk_PESSOA_idPessoa int
);

CREATE TABLE possui (
    fk_RELACIONAMENTO_idRelacionamento int,
    fk_PESSOA_idPessoa int
);
 
ALTER TABLE PESSOA ADD CONSTRAINT FK_PESSOA_2
    FOREIGN KEY (FK_email_email_PK)
    REFERENCES email (email_PK)
    ON DELETE NO ACTION;
 
ALTER TABLE possui ADD CONSTRAINT FK_possui_1
    FOREIGN KEY (fk_CARACTERISTICA_idCaracteristica)
    REFERENCES CARACTERISTICA (idCaracteristica)
    ON DELETE SET NULL;
 
ALTER TABLE possui ADD CONSTRAINT FK_possui_2
    FOREIGN KEY (fk_PESSOA_idPessoa)
    REFERENCES PESSOA (idPessoa)
    ON DELETE SET NULL;
 
ALTER TABLE possui ADD CONSTRAINT FK_possui_1
    FOREIGN KEY (fk_RELACIONAMENTO_idRelacionamento)
    REFERENCES RELACIONAMENTO (idRelacionamento)
    ON DELETE SET NULL;
 
ALTER TABLE possui ADD CONSTRAINT FK_possui_2
    FOREIGN KEY (fk_PESSOA_idPessoa)
    REFERENCES PESSOA (idPessoa)
    ON DELETE SET NULL;