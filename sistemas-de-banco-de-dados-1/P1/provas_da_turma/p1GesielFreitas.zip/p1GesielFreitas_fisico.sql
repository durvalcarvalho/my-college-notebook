-- -------- P1 ------------
-- 
--                    SCRIPT FISICO (DDL)
-- 
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Gesiel dos Santos Freitas
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: p1
-- 
-- PROJETO => 01 Base de Dados
--         => 07 Tabelas
-- 
-- -----------------------------------------------------------------

create database piGesiel if not exist

CREATE TABLE PROFESSOR (
    ultimoNome VARCHAR,
    sexo VARCHAR,
    dtNascimento DATE,
    primeiroNome VARCHAR,
    matriculaFuncional INTEGER PRIMARY KEY NOT NULL
) ENGINE = innodb;

CREATE TABLE PERIODO (
    nome VARCHAR,
    idPeriodo INTEGER PRIMARY KEY NOT NULL
) ENGINE = innodb;

CREATE TABLE DISCIPLINA (
    nomeCompleto VARCHAR,
    codigo INTEGER PRIMARY KEY NOT NULL,
    sigla VARCHAR,
    quantidadeCreditos INTEGER,
    idPeriodo INTEGER
    FOREIGN KEY (idPeriodo)
    REFERENCES PERIODO (idPeriodo)
    ON DELETE CASCADE;
) ENGINE = innodb;

CREATE TABLE PREREQUISITO (
    idPreRequisito INTEGER PRIMARY KEY NOT NULL,
    codigo INTEGER
    FOREIGN KEY (codigo)
    REFERENCES DISCIPLINA (codigo)
    ON DELETE CASCADE;
) ENGINE = innodb;

CREATE TABLE email (
    email VARCHAR,
    matriculaFuncional INTEGER
    FOREIGN KEY (matriculaFuncional)
    REFERENCES PROFESSOR (matriculaFuncional)
    ON DELETE RESTRICT;
    
) ENGINE = innodb;

CREATE TABLE tem (
    codigo INTEGER
    FOREIGN KEY (codigo)
    REFERENCES DISCIPLINA (codigo)
    ON DELETE RESTRICT,
    idPreRequisito INTEGER
    FOREIGN KEY (idPreRequisito)
    REFERENCES PREREQUISITO (idPreRequisito)
    ON DELETE SET NULL;
) ENGINE = innodb;

CREATE TABLE leciona (
    matriculaFuncional INTEGER
    FOREIGN KEY (matriculaFuncional)
    REFERENCES PROFESSOR (matriculaFuncional)
    ON DELETE RESTRICT,
    codigo INTEGER
    FOREIGN KEY (codigo)
    REFERENCES DISCIPLINA (codigo)
    ON DELETE RESTRICT;
) ENGINE = innodb;
 
    
 
