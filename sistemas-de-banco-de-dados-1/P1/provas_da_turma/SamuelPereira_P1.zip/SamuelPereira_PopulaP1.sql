-- --------     << Ambiente Virtual de Relacionamento >>     ------------
-- 
--                    SCRIPT DE MANIPULAÇÃO (DML)
-- 
-- Data Criacao ...........: 21/03/2018
-- Autor(es) ..............: Samuel de Souza Buters Pereira
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: bdRelacionamento
-- 
-- 
-- PROJETO => 01 Base de Dados
--         => 7 Tabelas
-- 
-- -----------------------------------------------------------------

INSERT INTO PESSOA(dtNascimento, sexo, primeiroNome, sobrenome, apelido) VALUES('1998-03-15', 'M', 'Rafael', 'Pereira', 'DarkLord123');
INSERT INTO PESSOA(dtNascimento, sexo, primeiroNome, sobrenome, apelido) VALUES('1996-02-21', 'F', 'Tereza', 'Almeida', 'Santa Tereza');
INSERT INTO PESSOA(dtNascimento, sexo, primeiroNome, sobrenome) VALUES('1995-02-21', 'F', 'Larissa', 'Teixeira');

INSERT INTO CARACTERISTICA(descCaracteristica) VALUES('Loiro(a)');
INSERT INTO CARACTERISTICA(descCaracteristica) VALUES('Branco(a)');
INSERT INTO CARACTERISTICA(descCaracteristica) VALUES('Cabelo Curto');
INSERT INTO CARACTERISTICA(descCaracteristica) VALUES('Negro(a)');

INSERT INTO INTERESSE(descInteresse) VALUES('Arte Visual');
INSERT INTO INTERESSE(descInteresse) VALUES('Engenharia');
INSERT INTO INTERESSE(descInteresse) VALUES('Literatura');

INSERT INTO email VALUES(1, 'rafael.feeder@gmail.com');
INSERT INTO email VALUES(1, 'rafa.elite@gmail.com');
INSERT INTO email VALUES(2, 'terezaprincesa@hotmail.com');
INSERT INTO email VALUES(3, 'larissa20192@hotmail.com');

INSERT INTO conhece VALUES(1, 2);
INSERT INTO conhece VALUES(3, 2);

INSERT INTO possui VALUES(1, 1);
INSERT INTO possui VALUES(1, 2);
INSERT INTO possui VALUES(2, 1);
INSERT INTO possui VALUES(2, 3);
INSERT INTO possui VALUES(3, 3);

INSERT INTO tem VALUES(1, 4);
INSERT INTO tem VALUES(2, 1);
INSERT INTO tem VALUES(2, 2);
INSERT INTO tem VALUES(3, 4);
INSERT INTO tem VALUES(3, 3);