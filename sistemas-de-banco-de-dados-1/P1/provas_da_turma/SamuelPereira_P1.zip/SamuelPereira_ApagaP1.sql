-- --------     << Ambiente Virtual de Relacionamento >>     ------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 21/03/2018
-- Autor(es) ..............: Samuel de Souza Buters Pereira
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: bdRelacionamento
-- 
-- 
-- PROJETO => 01 Base de Dados
--         => 7 Tabelas
-- 
-- -----------------------------------------------------------------

DROP TABLE tem;
DROP TABLE possui;
DROP TABLE conhece;
DROP TABLE email;
DROP TABLE INTERESSE;
DROP TABLE CARACTERISTICA;
DROP TABLE PESSOA;