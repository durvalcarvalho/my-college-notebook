-- --------     << Ambiente Virtual de Relacionamento >>     ------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 21/03/2018
-- Autor(es) ..............: Samuel de Souza Buters Pereira
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: bdRelacionamento
-- 
-- 
-- PROJETO => 01 Base de Dados
--         => 7 Tabelas
-- 
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS bdRelacionamento;
USE bdRelacionamento;

CREATE TABLE PESSOA (
    idPessoa INT NOT NULL AUTO_INCREMENT,
    dtNascimento DATE NOT NULL,
    sexo ENUM('F', 'M') NOT NULL,
    primeiroNome VARCHAR(25) NOT NULL,
    sobrenome VARCHAR(25) NOT NULL,
    apelido VARCHAR(25),

    CONSTRAINT PESSOA_PK PRIMARY KEY (idPessoa)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE CARACTERISTICA (
    idCaracteristica INT NOT NULL AUTO_INCREMENT,
    descCaracteristica VARCHAR(40) NOT NULL,

    CONSTRAINT CARACTERISTICA_PK PRIMARY KEY (idCaracteristica)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE INTERESSE (
    idInteresse INT NOT NULL AUTO_INCREMENT,
    descInteresse VARCHAR(40) NOT NULL,

    CONSTRAINT INTERESSE_PK PRIMARY KEY (idInteresse)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE email (
    idPessoa INT NOT NULL,
    email VARCHAR(40) NOT NULL,

   CONSTRAINT email_PESSOA_FK FOREIGN KEY (idPessoa)
   	REFERENCES PESSOA (idPessoa),
   CONSTRAINT email_UK UNIQUE (email) 
) ENGINE = InnoDB;

CREATE TABLE conhece (
    idPessoa INT NOT NULL,
    idPessoa2 INT NOT NULL,

   CONSTRAINT conhece_PESSOA_FK_1 FOREIGN KEY (idPessoa)
   	REFERENCES PESSOA (idPessoa),
   CONSTRAINT conhece_PESSOA_FK_2 FOREIGN KEY (idPessoa2)
   	REFERENCES PESSOA (idPessoa)
) ENGINE = InnoDB;

CREATE TABLE possui (
    idPessoa INT NOT NULL,
    idInteresse INT NOT NULL,

	CONSTRAINT possui_PESSOA_FK FOREIGN KEY (idPessoa)
		REFERENCES PESSOA (idPessoa),
	CONSTRAINT possui_INTERESSE_FK FOREIGN KEY (idInteresse)
		REFERENCES INTERESSE (idInteresse),
	CONSTRAINT possui_PK PRIMARY KEY (idPessoa, idInteresse)
) ENGINE = InnoDB;

CREATE TABLE tem (
    idPessoa INT NOT NULL,
    idCaracteristica INT NOT NULL,

	CONSTRAINT tem_PESSOA_FK FOREIGN KEY (idPessoa)
		REFERENCES PESSOA (idPessoa),
	CONSTRAINT tem_CARACTERISTICA_FK FOREIGN KEY (idCaracteristica)
		REFERENCES CARACTERISTICA (idCaracteristica),
	CONSTRAINT tem_PK PRIMARY KEY (idPessoa, idCaracteristica)
) ENGINE = InnoDB;