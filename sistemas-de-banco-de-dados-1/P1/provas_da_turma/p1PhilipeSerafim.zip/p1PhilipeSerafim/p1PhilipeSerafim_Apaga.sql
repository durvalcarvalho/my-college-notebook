﻿-- --------     philipeSerafim     ------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 21/03/2018
-- Autor(es) ..............: Philipe Rosa Serafim
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: philipeSerafim
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao do script APAGA
--
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
--         => 00 Sequencias
--         => 00 Visoes
--
-- -----------------------------------------------------------------

USE philipeSerafim;

DROP TABLE APROVOU;
DROP TABLE MATRICULA;
DROP TABLE LECIONA;
DROP TABLE DISCIPLINACONCLUIDA;
DROP TABLE EMAIL;
DROP TABLE REQUISITO;
DROP TABLE ALUNO;
DROP TABLE PROFESSOR;
DROP TABLE DISCIPLINA;