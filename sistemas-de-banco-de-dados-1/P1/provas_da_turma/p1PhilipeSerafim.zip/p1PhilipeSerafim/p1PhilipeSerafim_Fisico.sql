﻿-- --------     philipeSerafim     ------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 21/03/2018
-- Autor(es) ..............: Philipe Rosa Serafim
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: philipeSerafim
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao do script FISICO
-- 
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
--         => 00 Sequencias
--         => 00 Visoes
--
-- -----------------------------------------------------------------
CREATE DATABASE IF NOT EXISTS philipeSerafim;
USE philipeSerafim;

CREATE TABLE DISCIPLINA (
    codDisciplina INT(6) NOT NULL AUTO_INCREMENT,
    nome VARCHAR(35) NOT NULL,
    sigla VARCHAR(5) NOT NULL,
    qtdCredito INT(2) NOT NULL,
    periodo ENUM('M', 'V', 'N') NOT NULL,

    CONSTRAINT DISCIPLINA_PK PRIMARY KEY (codDisciplina)
)ENGINE = INNODB DEFAULT CHARSET utf8 AUTO_INCREMENT = 1;

CREATE TABLE PROFESSOR (
    matriculaFuncional BIGINT(10) NOT NULL AUTO_INCREMENT,
    nome VARCHAR(30) NOT NULL,
    dtNascimento DATE NOT NULL,
    sexo ENUM('M','F') NOT NULL,

    CONSTRAINT PROFESSOR_PK PRIMARY KEY (matriculaFuncional)
)ENGINE = INNODB DEFAULT CHARSET utf8 AUTO_INCREMENT = 1;

CREATE TABLE ALUNO (
    matricula BIGINT(10) NOT NULL AUTO_INCREMENT,
    nome VARCHAR(50) NOT NULL,
    dtNascimento DATE NOT NULL,
    cpf BIGINT(11) NOT NULL,

    CONSTRAINT ALUNO_PK PRIMARY KEY (matricula)
)ENGINE = INNODB DEFAULT CHARSET utf8 AUTO_INCREMENT = 1;

CREATE TABLE requisito (
    requisito INT(6),
    codDisciplina INT(6) NOT NULL,

    CONSTRAINT requisito_PK PRIMARY KEY (requisito, codDisciplina),
    CONSTRAINT requisito_FK FOREIGN KEY (codDisciplina) REFERENCES DISCIPLINA (codDisciplina)
)ENGINE = INNODB DEFAULT CHARSET utf8;

CREATE TABLE email (
    matriculaFuncional BIGINT(10) NOT NULL,
    email VARCHAR(35) NOT NULL,

    CONSTRAINT email_PK PRIMARY KEY (matriculaFuncional, email),
    CONSTRAINT email_FK FOREIGN KEY (matriculaFuncional) REFERENCES PROFESSOR (matriculaFuncional)
)ENGINE = INNODB DEFAULT CHARSET utf8;

CREATE TABLE disciplinaConcluida (
    disciplinaConcluida INT NOT NULL,
    matricula BIGINT(10) NOT NULL,

    CONSTRAINT disciplinaConcluida_PK PRIMARY KEY (disciplinaConcluida, matricula),
    CONSTRAINT disciplinaConcluida_ALUNO_FK FOREIGN KEY (matricula) REFERENCES ALUNO (matricula),
    CONSTRAINT disciplinaConcluida_DISCIPLINA_FK FOREIGN KEY (disciplinaConcluida) REFERENCES DISCIPLINA(codDisciplina)
)ENGINE = INNODB DEFAULT CHARSET utf8;

CREATE TABLE leciona (
    matriculaFuncional BIGINT(10) NOT NULL,
    codDisciplina INT(6) NOT NULL,

    CONSTRAINT leciona_PK PRIMARY KEY (codDisciplina, matriculaFuncional),
    CONSTRAINT leciona_PROFESSOR_FK FOREIGN KEY (matriculaFuncional) REFERENCES PROFESSOR(matriculaFuncional),
    CONSTRAINT leciona_DISCIPLINA_FK FOREIGN KEY (codDisciplina) REFERENCES DISCIPLINA (codDisciplina)
)ENGINE = INNODB DEFAULT CHARSET utf8;

CREATE TABLE matricula (
    matricula BIGINT(10) NOT NULL,
    codDisciplina INT(6) NOT NULL,

    CONSTRAINT matricula_PK PRIMARY KEY (matricula, codDisciplina),
    CONSTRAINT matricula_ALUNO_FK FOREIGN KEY (matricula) REFERENCES ALUNO (matricula),
    CONSTRAINT matricula_DISCIPLINA_FK FOREIGN KEY (codDisciplina) REFERENCES DISCIPLINA(codDisciplina)
)ENGINE = INNODB DEFAULT CHARSET utf8;

CREATE TABLE aprovou (
    codDisciplina INT(6) NOT NULL,
    matricula BIGINT(10) NOT NULL,

    CONSTRAINT aprovou_PK PRIMARY KEY (codDisciplina, matricula),
    CONSTRAINT aprovou_ALUNO_FK FOREIGN KEY (matricula) REFERENCES ALUNO (matricula),
    CONSTRAINT aprovou_DISCIPLINA_FK FOREIGN KEY (codDisciplina) REFERENCES DISCIPLINA (codDisciplina)
)ENGINE = INNODB DEFAULT CHARSET utf8;
