﻿-- --------     philipeSerafim     ------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 21/03/2018
-- Autor(es) ..............: Philipe Rosa Serafim
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: philipeSerafim
--
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao do script POPULA
--
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
--         => 00 Sequencias
--         => 00 Visoes
--
-- -----------------------------------------------------------------

USE philipeSerafim;

INSERT INTO ALUNO (nome, dtNascimento, cpf) VALUES
  ('Jose Ricardo', '1999-02-07', 852147893),
  ('Josefa Silva', '2000-05-09', 963258741);

INSERT INTO DISCIPLINA (nome, sigla, qtdCredito, periodo) VALUES
  ('Calculo 1', 'C1', 6, 'V'),
  ('Calculo 2', 'C2', 6, 'M');

INSERT INTO PROFESSOR (nome, dtNascimento, sexo) VALUES
  ('Ricardo Barros', '1975-09-08', 'M'),
  ('Tatiana Lemes',  '1986-12-10', 'F');


INSERT INTO EMAIL VALUES
  (1, 'ricardobarros@email.com'),
  (2, 'tatianalemes@email.com');

INSERT INTO LECIONA VALUES
  (1, 1),
  (2, 2);

INSERT INTO APROVOU VALUES
  (1, 1),
  (1, 2);

INSERT INTO MATRICULA VALUES
  (2, 1),
  (2, 2);

INSERT INTO DISCIPLINACONCLUIDA VALUES
  (1, 1),
  (1, 2);

INSERT INTO REQUISITO VALUES  (1, 2);