﻿-- --------     << PROVA 1 >>     ------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Leticia Meneses B. da Silva
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: leticiasilva
-- 
-- Data Ultima Alteracao ..: 17/10/2019
--   => Apaga tabelas
--
-- PROJETO => 01 Base de Dados
--         => 5 Tabelas
--         => 00 Sequencias
--         => 00 Visoes
--
-- -----------------------------------------------------------------

DROP TABLE cadastra;
DROP TABLE tem;
DROP TABLE PROFESSOR;
DROP TABLE PREREQUISITO;
DROP TABLE DISCIPLINA;

