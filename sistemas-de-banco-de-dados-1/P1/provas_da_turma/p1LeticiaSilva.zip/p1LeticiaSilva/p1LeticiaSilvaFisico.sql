﻿/* Lógico_LeticiaSilva_16-0131936: */

-- --------     << PROVA 1 >>     ------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Leticia Meneses B. da Silva
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: leticiasilva
-- 
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao do banco de dados
--
-- PROJETO => 01 Base de Dados
--         => 5 Tabelas
--         => 00 Sequencias
--         => 00 Visoes
--
-- -----------------------------------------------------------------
create database if not exists leticiasilva;
use leticiasilva;


CREATE TABLE DISCIPLINA (
    codigoDisciplina INTEGER NOT NULL,
    nomeDisciplina VARCHAR(50) NOT NULL,
    sigla VARCHAR(10) NOT NULL,
    qtCredito INTEGER NOT NULL,
    periodo VARCHAR(15) NOT NULL,

    CONSTRAINT DISCIPLINA_PK PRIMARY KEY(codigoDisciplina)
)ENGINE=InnoDB;

CREATE TABLE PREREQUISITO (
    nomePreReq VARCHAR(50) NOT NULL,
    codigoPreReq INTEGER NOT NULL,

    CONSTRAINT PREREQUISITO_PK PRIMARY KEY(codigoPreReq)
)ENGINE=InnoDB;

CREATE TABLE PROFESSOR (
    nomePrimeiro VARCHAR(15) NOT NULL,
    nomeUltimo VARCHAR(15) NOT NULL,
    dtNascimento VARCHAR(15) NOT NULL,
    sexo VARCHAR(1) NOT NULL,
    email VARCHAR(30) NOT NULL,
    matricula INTEGER NOT NULL,

    CONSTRAINT PROFESSOR_PK PRIMARY KEY(matricula)
)ENGINE=InnoDB;

CREATE TABLE tem (
    codigoDisciplina INTEGER NOT NULL,
    codigoPreReq INTEGER NOT NULL,

    CONSTRAINT tem_DISCIPLINA_FK FOREIGN KEY(codigoDisciplina) REFERENCES DISCIPLINA(codigoDisciplina),
    CONSTRAINT tem_PREREQUISITO_FK FOREIGN KEY(codigoPreReq) REFERENCES PREREQUISITO(codigoPreReq)

)ENGINE=InnoDB;

CREATE TABLE cadastra (
    codigoDisciplina INTEGER NOT NULL,
    matricula INTEGER NOT NULL,

    CONSTRAINT cadastra_DISCIPLINA_FK FOREIGN KEY(codigoDisciplina) REFERENCES DISCIPLINA(codigoDisciplina),
    CONSTRAINT cadastra_PROFESSOR_FK FOREIGN KEY(matricula) REFERENCES PROFESSOR(matricula)


)ENGINE=InnoDB;
