﻿
-- --------     << PROVA 1 >>     ------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Leticia Meneses B. da Silva
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: leticiasilva
-- 
-- Data Ultima Alteracao ..: 17/10/2019
--   => Criacao das tabelas
--
-- PROJETO => 01 Base de Dados
--         => 5 Tabelas
--         => 00 Sequencias
--         => 00 Visoes
--
-- -----------------------------------------------------------------
INSERT INTO DISCIPLINA(codigoDisciplina, nomeDisciplina, sigla, qtCredito, periodo) VALUES('1234', 'Sistema de Banco de Dados 1', 'SBD1', '004', 'vespertino');
INSERT INTO DISCIPLINA(codigoDisciplina, nomeDisciplina, sigla, qtCredito, periodo) VALUES('4567', 'Fundamentos de Sistemas Operacionais', 'FSO', '004', 'matutino');
INSERT INTO PREREQUISITO(nomePreReq, codigoPreReq) VALUES('Matematica Discreta 1', '0125');
INSERT INTO PREREQUISITO(nomePreReq, codigoPreReq) VALUES('Fundamento de Arquitetura de Computadores', '1548');
INSERT INTO PROFESSOR(nomePrimeiro, nomeUltimo, dtNascimento, sexo, email, matricula) VALUES('Ricardo', 'Teixeira', '10/02/1980', 'm', 'rteixeira@email.com', '30625148');
INSERT INTO PROFESSOR(nomePrimeiro, nomeUltimo, dtNascimento, sexo, email, matricula) VALUES('Ana', 'Almeida', '25/09/1975', 'f', 'anaalmeida@email.com', '38451256');
INSERT INTO tem(codigoDisciplina, codigoPreReq) VALUES('1234', '0125');
INSERT INTO tem(codigoDisciplina, codigoPreReq) VALUES('4567', '1548');
INSERT INTO cadastra(codigoDisciplina, matricula) VALUES('1234', '30625148');
INSERT INTO cadastra(codigoDisciplina, matricula) VALUES('4567', '38451256');


