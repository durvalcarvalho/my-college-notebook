﻿use p1JoaoCarneiro;

INSERT INTO preRequisito(nomeDisciplina, sigla) VALUES ('Sistemas Aerospaciais', 'SA');
INSERT INTO preRequisito(nomeDisciplina, sigla) VALUES ('Calculo 1', 'C1');

INSERT INTO email(email) VALUES ('silvio.augusto@unb.br');
INSERT INTO email(email) VALUES ('sandraFigueira@gmail.com');

INSERT INTO Disciplina(nomeDisciplina, sigla,qntdDeCreditos,periodo, preRequisito) VALUES ('Controle Aeroespacial', 'CA', 4, 5, 'Sistemas Aerospaciais');
INSERT INTO Disciplina(nomeDisciplina, sigla,qntdDeCreditos,periodo, preRequisito) VALUES ('Sistemas Aerospaciais', 'SA', 4, 5, 'Calculo 1');

INSERT INTO Professor (primeiroNome, ultimoNome, dataNascimento,  sexo, email, cpf) VALUES ('Sandra', 'Figueiredo', '14/11/1995', 'Feminino','andraFigueira@gmail.com', 05534477732);
INSERT INTO Professor (primeiroNome, ultimoNome, dataNascimento,  sexo, email, cpf) VALUES ('Silvio', 'Augusto', '12/11/1995', 'Masculino','silvio.augusto@unb.br', 05594877712);

INSERT INTO Leciona (Professor_cpf, Disciplina_nomeDisciplina, Disciplina_sigla, Disciplina_periodo ) VALUES (05534477732, 'Sistemas Aerospaciais', 'SA', 5);
INSERT INTO Leciona (Professor_cpf, Disciplina_nomeDisciplina, Disciplina_sigla, Disciplina_periodo ) VALUES (05534477732, 'Sistemas Aerospaciais', 'SA', 5);