﻿CREATE DATABASE p1JoaoCarneiro;


USE p1JoaoCarneiro;

CREATE TABLE preRequisito (
    nomeDisciplina VARCHAR(40) NOT NULL,
    sigla VARCHAR(6) NOT NULL,
    CONSTRAINT preRequisito_PK PRIMARY KEY (nomeDisciplina, sigla)
);

CREATE TABLE email (
    email VARCHAR(40) NOT NULL,
    CONSTRAINT email_PK PRIMARY KEY (email)
);

CREATE TABLE Disciplina (
    nomeDisciplina VARCHAR(40) NOT NULL,
    sigla VARCHAR(6) NOT NULL,
    qntdDeCreditos INT NOT NULL,
    periodo INT NOT NULL,
    preRequisito VARCHAR(40),
    CONSTRAINT Disciplina_PK PRIMARY KEY (nomeDisciplina, sigla, periodo),
    CONSTRAINT Disciplina_prerequisito_FK FOREIGN KEY (preRequisito)
      REFERENCES preRequisito(nomeDisciplina)
);

CREATE TABLE Professor (
    primeiroNome VARCHAR(30) NOT NULL,
    ultimoNome VARCHAR(30) NOT NULL,
    dataNascimento DATE NOT NULL,
    sexo VARCHAR(30) NOT NULL,
    idade INT NOT NULL,
    email VARCHAR(40) NOT NULL,
    cpf BIGINT(11) NOT NULL,
    CONSTRAINT Professor_PK PRIMARY KEY (cpf),
    CONSTRAINT Professor_email_FK FOREIGN KEY (email)
      REFERENCES email(email)
);


CREATE TABLE leciona (
    Professor_cpf BIGINT(11) NOT NULL,
    Disciplina_nomeDisciplina VARCHAR(40) NOT NULL,
    Disciplina_sigla VARCHAR(6) NOT NULL,
    Disciplina_periodo INT NOT NULL,
    CONSTRAINT leciona_Professor_FK FOREIGN KEY (Professor_cpf)
      REFERENCES professor(cpf),
    CONSTRAINT leciona_Disciplina_FK FOREIGN KEY (Disciplina_nomeDisciplina, Disciplina_sigla, Disciplina_periodo)
      REFERENCES Disciplina(nomeDisciplina, sigla, periodo)
);