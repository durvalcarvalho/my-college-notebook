﻿use p1JoaoCarneiro;

DROP TABLE leciona;

DROP TABLE Professor;

DROP TABLE Disciplina;

DROP TABLE email;

DROP TABLE preRequisito;