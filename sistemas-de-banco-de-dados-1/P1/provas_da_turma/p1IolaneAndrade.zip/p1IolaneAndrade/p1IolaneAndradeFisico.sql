﻿/* IolaneAndrade */
/* Projeto de Banco de Dados: Cadastro de Disciplina
*/


CREATE DATABASE iolaneandrade if not exist;
use iolaneandrade;

CREATE TABLE PROFESSOR (
    matriculaProfessor INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(30) NOT NULL,
    sobrenome VARCHAR(30) NOT NULL,
    sexo ENUM('M', 'F'),
    dataNascimento DATE NOT NULL,
    codigoEspecialidade INT,
    FK_email_email_PK VARCHAR(50)
)ENGINE=innob;

CREATE TABLE DISCIPLINA (
    codigoDisciplina INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(40) NOT NULL,
    sigla VARCHAR(5) NOT NULL,
    quantidadeCreditos INT,
    periodo ENUM('M','V','N'),
    codigoPreRequisito INT,
    matriculaProfessor INT
)ENGINE=innob;

CREATE TABLE ESPECIALIDADE (
    codigoEspecialidade INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    descricaoEspecialidade VARCHAR(40) NOT NULL
)ENGINE=innob;

CREATE TABLE PRE_REQUISITO (
    codigoPreRequisito INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    descricao VARCHAR(40) NOT NULL
)ENGINE=innob;

CREATE TABLE email (
    email_PK VARCHAR(50) NOT NULL PRIMARY KEY,
    email VARCHAR(50) NOT NULL
);

CREATE TABLE possui (
    PROFESSOR_matriculaProfessor INT,
    ESPECIALIDADE_codigoEspecialidade INT
);

CREATE TABLE possui (
    PRE_REQUISITO_codigoPreRequisito INT,
    DISCIPLINA_codigoDisciplina INT
);

CREATE TABLE leciona (
    PROFESSOR_matriculaProfessor INT,
    DISCIPLINA_codigoDisciplina INT
);

ALTER TABLE PROFESSOR ADD CONSTRAINT FK_PROFESSOR_2
    FOREIGN KEY (FK_email_email_PK)
    REFERENCES email (email_PK)
    ON DELETE NO ACTION;

ALTER TABLE possui ADD CONSTRAINT FK_possui_1
    FOREIGN KEY (PROFESSOR_matriculaProfessor)
    REFERENCES PROFESSOR (matriculaProfessor)
    ON DELETE RESTRICT;

ALTER TABLE possui ADD CONSTRAINT FK_possui_2
    FOREIGN KEY (ESPECIALIDADE_codigoEspecialidade)
    REFERENCES ESPECIALIDADE (codigoEspecialidade)
    ON DELETE RESTRICT;

ALTER TABLE possui ADD CONSTRAINT FK_possui_1
    FOREIGN KEY (PRE_REQUISITO_codigoPreRequisito)
    REFERENCES PRE_REQUISITO (codigoPreRequisito)
    ON DELETE RESTRICT;

ALTER TABLE possui ADD CONSTRAINT FK_possui_2
    FOREIGN KEY (DISCIPLINA_codigoDisciplina)
    REFERENCES DISCIPLINA (codigoDisciplina)
    ON DELETE SET NULL;

ALTER TABLE leciona ADD CONSTRAINT FK_leciona_1
    FOREIGN KEY (PROFESSOR_matriculaProfessor)
    REFERENCES PROFESSOR (matriculaProfessor)
    ON DELETE RESTRICT;

ALTER TABLE leciona ADD CONSTRAINT FK_leciona_2
    FOREIGN KEY (DISCIPLINA_codigoDisciplina)
    REFERENCES DISCIPLINA (codigoDisciplina)
    ON DELETE RESTRICT;