/* L�gico: */

CREATE TABLE PROFESSOR (
    idProfessor INT NOTNULL PRIMARY KEY,
    primeiro varchar(20) NOTNULL,
    ultimo varchar(20) NOTNULL,
    dtNascimento DT,
    sexo varchar(1),
    idade INT,
    FK_email_email_PK INT NOTNULL
);

CREATE TABLE DISCIPLINA (
    nomeCompleto varchar(20) NOTNULL,
    sigla varchar(4) NOTNULL PRIMARY KEY,
    periodo varchar(1)
);

CREATE TABLE email (
    idEmail INT NOTNULL PRIMARY KEY,
    email varchar(40) NOTNULL
);

CREATE TABLE leciona (
    sigla varchar(4) NOTNULL,
    idProfessor INT NOTNULL
);

CREATE TABLE possui (
    sigla varchar(4) NOTNULL,
    idRequisito varchar(20) NOTNULL
);

CREATE TABLE Tabela_1 (
    idRequisito INT NOTNULL PRIMARY KEY,
    nome NOTNULL
);
 
ALTER TABLE PROFESSOR ADD CONSTRAINT FK_PROFESSOR_2
    FOREIGN KEY (FK_email_email_PK)
    REFERENCES email (idEmail)
    ON DELETE NO ACTION;
 
ALTER TABLE leciona ADD CONSTRAINT FK_leciona_1
    FOREIGN KEY (sigla)
    REFERENCES DISCIPLINA (sigla)
    ON DELETE RESTRICT;
 
ALTER TABLE leciona ADD CONSTRAINT FK_leciona_2
    FOREIGN KEY (idProfessor)
    REFERENCES PROFESSOR (idProfessor)
    ON DELETE RESTRICT;
 
ALTER TABLE possui ADD CONSTRAINT FK_possui_1
    FOREIGN KEY (sigla???, idRequisito???)
    REFERENCES ??? (???);