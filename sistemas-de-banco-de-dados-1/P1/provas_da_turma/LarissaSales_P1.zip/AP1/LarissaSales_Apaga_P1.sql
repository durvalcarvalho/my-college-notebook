﻿-- --------     << LarissaSalesP1 >>     ------------
--
--              SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Larissa Siqueira Sales
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: larissasales
--
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--
-- ---------------------------------------------------
USE larissasales;

DROP TABLE relaciona;

DROP TABLE interesses;

DROP TABLE caracteristicas;

DROP TABLE email;

DROP TABLE PESSOA;
