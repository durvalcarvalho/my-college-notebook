﻿-- ---------- Banco do Ambiente Virtual ---------
--
--
--               Script de criação DDL
--
-- Data de criação:17/10/2019
-- Autor:Nathalia Lorena Cardoso Dias
-- Banco de dados :Mysql
-- Modelo lógico para físico
--

CREATE DATABASE IF NOT EXISTS bdAmbienteVirtual;
USE bdAmbienteVirtual;

CREATE TABLE PESSOA (
    nome VARCHAR(2) NOT NULL,
    idade INT NOT NULL,
    sexo CHAR NOT NULL,
    dataNascimento DATE NOT NULL,
    email VARCHAR(20) NOT NULL PRIMARY KEY,
    quantidadeRelacionamentos BIGINT NOT NULL
)ENGINE = InnoDB;


CREATE TABLE AMBIENTEVIRTUAL (
    nome VARCHAR(30) NOT NULL,
    apelido VARCHAR(20) PRIMARY KEY
)ENGINE = InnoDB;


CREATE TABLE INTERESSES (
)ENGINE = InnoDB;


CREATE TABLE CARACTERISTICASPESSOAIS (
)ENGINE = InnoDB;


CREATE TABLE email (
    email VARCHAR(20) NOT NULL,
    email VARCHAR(20) NOT NULL,
    PRIMARY KEY (email, email)
)ENGINE = InnoDB;


CREATE TABLE quantidadeRelacionamentos (
    quantidadeRelacionamentos BIGINT NOT NULL PRIMARY KEY,
    quantidadeRelacionamentos BIGINT
)ENGINE = InnoDB;


CREATE TABLE relaciona (
    apelido VARCHAR(20) NOT NULL
)ENGINE = InnoDB;


CREATE TABLE possui (
)ENGINE = InnoDB;


CREATE TABLE possui (
)ENGINE = InnoDB;

