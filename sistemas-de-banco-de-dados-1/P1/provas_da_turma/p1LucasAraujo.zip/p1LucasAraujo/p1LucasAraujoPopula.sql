USE p1LucasAraujo;

INSERT INTO PERIODO(descricao) VALUES ('matutino'), ('vespertino'), ('noturno');

INSERT INTO DISCIPLINA(qtdCreditos, sigla, nome, codigoPeriodo) VALUES
  (6, 'C1', 'Calculo 1', 1),
  (4, 'EMC', 'Estruturas matematicas para computacao', 1),
  (6, 'CB', 'Computacao Basica', 2 );

INSERT INTO PROFESSOR(cpf, sexo, dtNascimento, primeiroNome, ultimoNome) VALUES
  (05155078148, 'M', DATE('1980-04-20'), 'Seu Jorge', 'Matador de Dragoes'),
  (05155078142, 'M', DATE('1982-12-22'), 'Robesval', 'segundo'),
  (05155078138, 'M', DATE('1970-09-17'), 'Julian', 'terceiro');

INSERT INTO EMAIL(cpf, email) VALUES(05155078148,'email@gmail.com'), (05155078148,'outroEmail@gmail.com'), (05155078142,'queisso@gmail.com'), (05155078138,'segundo@gmail.com');


INSERT INTO PREREQUISITA(codigoDisciplinaOrigem, codigoDisciplinaPrerequisito) values (3,1), (3,2);


