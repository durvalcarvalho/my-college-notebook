﻿-- --------            << P1fisico >>        ------------
--
--                    SCRIPT DE APAGA (DML)
--                                                                  
-- Data Criacao ..........: 17/10/2019
-- Autor(es) .............: Ivan Diniz Dobbin
-- Banco de Dados ........: MySQL                                   
-- Base de Dados(nome) ...: P1fisico
--
--
-- PROJETO => 1 Base de Dados                                       
--         => 7 Tabelas
--                                                                  
-- -----------------------------------------------------------------

USE P1fisico;

DROP TABLE SIGLA;
DROP TABLE leciona;
DROP TABLE email;
DROP TABLE idPrerequisito;
DROP TABLE PROFESSOR;
DROP TABLE DISCIPLINA;
DROP TABLE PERIODO;
