﻿-- --------            << P1fisico>>        ------------
--                                                                  
--                    SCRIPT CRIAÇÃO (DDL)
--                                                                  
-- Data Criacao ..........: 17/10/2019
-- Autor(es) .............: Ivan Diniz Dobbin
-- Banco de Dados ........: MySQL
-- Base de Dados(nome) ...: P1fisico
--
--                                                                  
-- PROJETO => 1 Base de Dados                                       
--         => 7 Tabelas
--                                                                  
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS P1fisico;
USE P1fisico;



CREATE TABLE PERIODO (
    idPeriodo INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(15) NOT NULL,
    CONSTRAINT PERIODO_PK PRIMARY KEY(idPeriodo)
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE DISCIPLINA (
    nome VARCHAR(100) NOT NULL,
    idDisciplina INT NOT NULL AUTO_INCREMENT,
    quantCredito INT NOT NULL,
    idPeriodo INT NOT NULL,
    CONSTRAINT DISCIPLINA_PK PRIMARY KEY(idDisciplina),
    CONSTRAINT DISCIPLINA_PERIODO_FK FOREIGN KEY(idPeriodo) REFERENCES PERIODO(idPeriodo)
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE PROFESSOR (
    nome VARCHAR(100) NOT NULL,
    dataNascimento DATE NOT NULL,
    sexo VARCHAR(1) NOT NULL,
    idProfessor INT NOT NULL AUTO_INCREMENT,
    CONSTRAINT PROFESSOR_PK PRIMARY KEY(idProfessor)
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE idPrerequisito (
    idDisciplina INT NOT NULL,
    idPrerequisito INT NOT NULL,
    CONSTRAINT idPrerequisito_PK PRIMARY KEY (idDisciplina, idPrerequisito),
    CONSTRAINT idPrerequisito_DISCIPLINA_FK FOREIGN KEY(idDisciplina) REFERENCES DISCIPLINA(idDisciplina)
)ENGINE = InnoDB;

CREATE TABLE email (
    idProfessor INT NOT NULL,
    email VARCHAR(100) NOT NULL,
    CONSTRAINT email_PK PRIMARY KEY (idProfessor, email),
    CONSTRAINT email_PROFESSOR_FK FOREIGN KEY(idProfessor) REFERENCES PROFESSOR(idProfessor)
)ENGINE = InnoDB ;

CREATE TABLE leciona (
    idProfessor INT NOT NULL,
    idDisciplina INT NOT NULL,
    CONSTRAINT leciona_PK PRIMARY KEY (idProfessor, idDisciplina),
    CONSTRAINT leciona_PROFESSOR_FK FOREIGN KEY(idProfessor) REFERENCES PROFESSOR(idProfessor),
    CONSTRAINT leciona_DISCIPLINA_FK FOREIGN KEY (idDisciplina) REFERENCES DISCIPLINA(idDisciplina)
)ENGINE = InnoDB;

CREATE TABLE SIGLA (
    idSigla INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(10) NOT NULL,
    idDisciplina INT NOT NULL,
    CONSTRAINT SIGLA_PK PRIMARY KEY(idSigla),
    CONSTRAINT SIGLA_DISCIPLINA_FK FOREIGN KEY(idDisciplina) REFERENCES DISCIPLINA(idDisciplina)
)ENGINE = InnoDB AUTO_INCREMENT = 1;
