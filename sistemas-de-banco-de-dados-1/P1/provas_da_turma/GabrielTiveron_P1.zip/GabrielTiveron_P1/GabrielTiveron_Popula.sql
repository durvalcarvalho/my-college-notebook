﻿-- --------    Avalia��o Presencial 1    ------------
--
--                    SCRIPT DE POPULACAO (DML)
-- 
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Gabriel Marques Tiveron
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: gabrieltiveron
--
--
-- PROJETO => 01 Base de Dados
--         => 7 Tabelas
--
-- -----------------------------------------------------------------

INSERT INTO PESSOA VALUES('Gabriel', 'Tiveron', 'tiveron', '28-02-1999', 'gabriel@email.com'),
                         ('Leticia', 'Magalhae', 'let', '22-03-1995', 'let@email.com'),
                         ('Isabelle', 'Rodrigues', 'belle', '03-09-1999', 'belle@email.com');

INSERT INTO CARACTERISTICA VALUES('Loira(o)'),
                                 ('Inteligente'),
                                 ('Alegre');

INSERT INTO INTERESSE VALUES('Futebol'),
                            ('Xadrez'),
                            ('Livros');

INSERT INTO emailSecundario VALUES('belle@email.com', 'belle123@email.com'),
                                  ('let@email.com', 'let12@email.com');

INSERT INTO relaciona VALUES('belle@email.com', 'let@email.com'),
                            ('let@email.com', 'gabriel@email.com');

INSERT INTO tem VALUES(1, 'gabriel@email.com'),
                      (3, 'belle@email.com');

INSERT INTO possui VALUES(2, 'belle@email.com'),
                         (1, 'let@email.com');