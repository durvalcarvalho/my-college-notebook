﻿-- --------    Avaliação Presencial 1    ------------
--
--                    SCRIPT DE REMOÇÃO (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Gabriel Marques Tiveron
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: gabrieltiveron
--
--
-- PROJETO => 01 Base de Dados
--         => 7 Tabelas
-- 
-- -----------------------------------------------------------------

USE gabrieltiveron;

DROP TABLE possui;
DROP TABLE tem;
DROP TABLE relaciona;
DROP TABLE emailSecundario;
DROP TABLE INTERESSE;
DROP TABLE CARACTERISTICA;
DROP TABLE PESSOA;
