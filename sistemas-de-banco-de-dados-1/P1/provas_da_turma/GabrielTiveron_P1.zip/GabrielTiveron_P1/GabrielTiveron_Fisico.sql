﻿-- --------    Avalia��o Presencial 1    ------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Gabriel Marques Tiveron
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: gabrieltiveron
--
-- 
-- PROJETO => 01 Base de Dados
--         => 7 Tabelas
-- 
-- -----------------------------------------------------------------

CREATE DATABASE If NOT EXISTS gabrieltiveron;

USE gabrieltiveron;

CREATE TABLE PESSOA (
    primeiroNome varchar(30) NOT NULL,
    ultimoNome varchar(30) NOT NULL,
    apelido varchar(20) NOT NULL,
    dtNasc date NOT NULL,
    emailPrincipal varchar(100) NOT NULL,
    sexo varchar(1) NOT NULL,

    CONSTRAINT PESSOA_PK PRIMARY KEY(emailPrincipal)
)ENGINE=INNODB;

CREATE TABLE CARACTERISTICA (
    idCaracteristica INT NOT NULL AUTO_INCREMENT,
    descCaracteristica varchar(20) NOT NULL,

    CONSTRAINT CARACTERISTICA_PK PRIMARY KEY(idCaracteristica),
    CONSTRAINT CARACTERISTICA_UK UNIQUE KEY (descCaracteristica)
)ENGINE=INNODB AUTO_INCREMENT=1;

CREATE TABLE INTERESSE (
    idInteresse INT NOT NULL AUTO_INCREMENT,
    descInteresse varchar(30) NOT NULL,

    CONSTRAINT INTERESSE_PK PRIMARY KEY(idInteresse),
    CONSTRAINT INTERESSE_UK UNIQUE KEY(descInteresse)
)ENGINE=INNODB AUTO_INCREMENT=1;

CREATE TABLE emailSecundario (
    emailPrincipal varchar(100) NOT NULL,
    emailSecundario varchar(100) NOT NULL,

    CONSTRAINT emailSecundario_FK FOREIGN KEY(emailPrincipal)
      REFERENCES PESSOA(emailPrincipal),
    CONSTRAINT emailSecundario_PK PRIMARY KEY(emailPrincipal, emailSecundario)
)ENGINE=INNODB;

CREATE TABLE relaciona (
    emailRelacionado varchar(100) NOT NULL,
    emailPrincipal varchar(100) NOT NULL,

    CONSTRAINT relaciona_FK FOREIGN KEY (emailPrincipal)
      REFERENCES PESSOA(emailPrincipal),
    CONSTRAINT PESSOA_relaciona_FK FOREIGN KEY (emailRelacionado)
      REFERENCES PESSOA(emailPrincipal),
    CONSTRAINT relaciona_UK UNIQUE KEY (emailPrincipal, emailRelacionado)
)ENGINE=INNODB;

CREATE TABLE tem (
    idCaracteristica INT NOT NULL,
    emailPrincipal varchar(100) NOT NULL,

    CONSTRAINT PESSOA_tem_FK FOREIGN KEY (emailPrincipal)
      REFERENCES PESSOA(emailPrincipal),
    CONSTRAINT tem_CARACTERISTICA_FK FOREIGN KEY (idCaracteristica)
      REFERENCES CARACTERISTICA(idCaracteristica),
    CONSTRAINT tem_UK UNIQUE KEY (idCaracteristica, emailPrincipal)
)ENGINE=INNODB;

CREATE TABLE possui (
    idInteresse INT NOT NULL AUTO_INCREMENT,
    emailPrincipal varchar(100) NOT NULL,

    CONSTRAINT PESSOA_possui_FK FOREIGN KEY (emailPrincipal)
      REFERENCES PESSOA(emailPrincipal),
    CONSTRAINT possui_INTERESSE_FK FOREIGN KEY (idInteresse)
      REFERENCES INTERESSE(idInteresse),
    CONSTRAINT possui_UK UNIQUE KEY (idInteresse, emailPrincipal)
)ENGINE=INNODB AUTO_INCREMENT=1;